#!/bin/bash

echo 'Content-type: text/plain'
echo
echo

/usr/bin/mpc stop 
echo "Radio stopped..."
